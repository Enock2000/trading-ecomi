import { config } from 'dotenv';
config();

import '@/ai/flows/provide-summary-insights.ts';
import '@/ai/flows/generate-trade-comparison-chart.ts';