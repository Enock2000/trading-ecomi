'use server';

/**
 * @fileOverview A trade data summarization AI agent.
 *
 * - provideSummaryInsights - A function that provides summarized insights from trade data comparison.
 * - SummaryInsightsInput - The input type for the provideSummaryInsights function.
 * - SummaryInsightsOutput - The return type for the provideSummaryInsights function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummaryInsightsInputSchema = z.object({
  country1: z.string().describe('The name of the first country.'),
  country2: z.string().describe('The name of the second country.'),
  tradeData: z.string().describe('The trade data between the two countries in JSON format.'),
});
export type SummaryInsightsInput = z.infer<typeof SummaryInsightsInputSchema>;

const SummaryInsightsOutputSchema = z.object({
  summary: z.string().describe('A summarized insight of the trade data comparison.'),
});
export type SummaryInsightsOutput = z.infer<typeof SummaryInsightsOutputSchema>;

export async function provideSummaryInsights(input: SummaryInsightsInput): Promise<SummaryInsightsOutput> {
  return provideSummaryInsightsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'provideSummaryInsightsPrompt',
  input: {schema: SummaryInsightsInputSchema},
  output: {schema: SummaryInsightsOutputSchema},
  prompt: `You are an expert trade analyst. Provide a summarized insight of the trade data comparison between {{country1}} and {{country2}}, highlighting significant trends and balances. Base your analysis on the following trade data: {{{tradeData}}}. Focus on providing a quick overview without overwhelming with raw data.`,
});

const provideSummaryInsightsFlow = ai.defineFlow(
  {
    name: 'provideSummaryInsightsFlow',
    inputSchema: SummaryInsightsInputSchema,
    outputSchema: SummaryInsightsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
