'use server';
/**
 * @fileOverview Generates a comparison chart highlighting key differences and trends in trade data between two selected countries.
 *
 * - generateTradeComparisonChart - A function that generates the trade comparison chart.
 * - GenerateTradeComparisonChartInput - The input type for the generateTradeComparisonChart function.
 * - GenerateTradeComparisonChartOutput - The return type for the generateTradeComparisonChart function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateTradeComparisonChartInputSchema = z.object({
  country1Name: z.string().describe('The name of the first country.'),
  country1Data: z.string().describe('Trade data for the first country in JSON format.'),
  country2Name: z.string().describe('The name of the second country.'),
  country2Data: z.string().describe('Trade data for the second country in JSON format.'),
});
export type GenerateTradeComparisonChartInput = z.infer<typeof GenerateTradeComparisonChartInputSchema>;

const ChartDataItemSchema = z.object({
  year: z.number().describe('The year for the data point.'),
  country1_exports: z.number().describe('Exports for country 1 in billions USD.'),
  country1_imports: z.number().describe('Imports for country 1 in billions USD.'),
  country2_exports: z.number().describe('Exports for country 2 in billions USD.'),
  country2_imports: z.number().describe('Imports for country 2 in billions USD.'),
});

const GenerateTradeComparisonChartOutputSchema = z.object({
  chartDescription: z
    .string()
    .describe(
      'A textual description of the trade comparison chart, highlighting key differences and trends.'
    ),
  chartData: z
    .array(ChartDataItemSchema)
    .describe('The data for the chart.'),
});
export type GenerateTradeComparisonChartOutput = z.infer<typeof GenerateTradeComparisonChartOutputSchema>;

export async function generateTradeComparisonChart(
  input: GenerateTradeComparisonChartInput
): Promise<GenerateTradeComparisonChartOutput> {
  return generateTradeComparisonChartFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateTradeComparisonChartPrompt',
  input: {schema: GenerateTradeComparisonChartInputSchema},
  output: {schema: GenerateTradeComparisonChartOutputSchema},
  prompt: `You are an expert trade data analyst. You will generate data for a comparison chart highlighting key differences and trends in trade data between two selected countries.

  Country 1: {{{country1Name}}}
  Country 1 Data: {{{country1Data}}}
  Country 2: {{{country2Name}}}
  Country 2 Data: {{{country2Data}}}

  Based on the provided data, create a compelling chart data and a textual description of the chart highlighting key differences and trends in trade data.
  The chart data should be structured for a charting library. For each year, provide the exports and imports for both countries.
  Use the following keys for the chart data objects: 'year', 'country1_exports', 'country1_imports', 'country2_exports', 'country2_imports'.
  `,
});

const generateTradeComparisonChartFlow = ai.defineFlow(
  {
    name: 'generateTradeComparisonChartFlow',
    inputSchema: GenerateTradeComparisonChartInputSchema,
    outputSchema: GenerateTradeComparisonChartOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);

    const chartData = JSON.parse(input.country1Data).map((d1: any) => {
        const d2 = JSON.parse(input.country2Data).find((d: any) => d.year === d1.year);
        return {
            year: d1.year,
            country1_exports: d1.exports,
            country1_imports: d1.imports,
            country2_exports: d2?.exports,
            country2_imports: d2?.imports,
        };
    });

    return {
        chartData,
        chartDescription: output?.chartDescription || `An AI-generated visual analysis comparing the trade data of ${input.country1Name} and ${input.country2Name}.`
    };
  }
);
